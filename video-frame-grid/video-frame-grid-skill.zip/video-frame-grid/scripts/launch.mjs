import fs from "node:fs/promises";
import { openSync, closeSync } from "node:fs";
import { spawn, spawnSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import { createRequire } from "node:module";
import net from "node:net";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const appDir = path.join(root, "assets", "app");
const runtime = path.join(root, ".runtime");
const stateFile = path.join(runtime, "server.json");
const args = process.argv.slice(2);
const action = args.find((item) => !item.startsWith("--") && !/^\d+$/.test(item)) || "start";
const portIndex = args.indexOf("--port");
const preferredPort = portIndex < 0 ? 4173 : Number(args[portIndex + 1]);
const browserBlockedPorts = new Set([1719, 1720, 1723, 2049, 3659, 4045, 4190, 5060, 5061, 6000, 6566, 6665, 6666, 6667, 6668, 6669, 6697, 10080]);
if (!["start", "status", "stop"].includes(action) || !Number.isInteger(preferredPort) || preferredPort < 1024 || preferredPort > 65535) {
  throw new Error("Usage: node scripts/launch.mjs [start|status|stop] [--port 4180]");
}

async function health(port) {
  try {
    const response = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(1500) });
    return response.ok ? await response.json() : null;
  } catch { return null; }
}

async function readState() {
  try { return JSON.parse(await fs.readFile(stateFile, "utf8")); }
  catch { return null; }
}

async function available(port) {
  if (browserBlockedPorts.has(port)) return false;
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once("error", () => resolve(false));
    server.listen(port, "127.0.0.1", () => server.close(() => resolve(true)));
  });
}

async function installDependencies() {
  const require = createRequire(path.join(appDir, "package.json"));
  try {
    const manifest = JSON.parse(await fs.readFile(path.join(appDir, "package.json"), "utf8"));
    for (const dependency of Object.keys(manifest.dependencies)) require.resolve(dependency);
    await fs.access(require("ffmpeg-static"));
    await fs.access(require("ffprobe-static").path);
    return;
  } catch {}
  console.log("Installing video tool dependencies and FFmpeg...");
  const result = process.platform === "win32"
    ? spawnSync(process.env.ComSpec || "cmd.exe", ["/d", "/s", "/c", "npm ci"], { cwd: appDir, windowsHide: true, stdio: "inherit" })
    : spawnSync("npm", ["ci"], { cwd: appDir, stdio: "inherit" });
  if (result.error || result.status !== 0) throw new Error("Dependency installation failed. Check the npm output above.");
}

await fs.mkdir(runtime, { recursive: true });
const state = await readState();
const current = state ? await health(state.port) : null;
const owned = current?.app === "video-frame-grid" && current?.instanceId === state?.instanceId && current?.pid === state?.pid;

if (action === "status") {
  console.log(JSON.stringify(owned ? { running: true, url: `http://localhost:${state.port}`, pid: state.pid } : { running: false }));
} else if (action === "stop") {
  if (owned) {
    process.kill(state.pid);
    for (let attempt = 0; attempt < 30; attempt++) {
      if (!(await health(state.port))) break;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    if (await health(state.port)) throw new Error("Server has not stopped yet.");
    await fs.rm(stateFile, { force: true });
  }
  console.log(JSON.stringify({ running: false, stopped: owned }));
} else if (owned) {
  console.log(JSON.stringify({ running: true, reused: true, url: `http://localhost:${state.port}`, pid: state.pid }));
} else {
  if (Number(process.versions.node.split(".")[0]) < 20) throw new Error("Node.js 20 or newer is required.");
  await installDependencies();
  let port = preferredPort;
  while (port < preferredPort + 20 && port <= 65535 && !(await available(port))) port++;
  if (port >= preferredPort + 20 || port > 65535) throw new Error("No available local port. Use --port to choose another range.");
  const instanceId = randomUUID();
  const stdout = openSync(path.join(runtime, "server.log"), "a");
  const stderr = openSync(path.join(runtime, "server-error.log"), "a");
  const child = spawn(process.execPath, [path.join(appDir, "server.mjs")], {
    cwd: appDir, detached: true, windowsHide: true,
    env: { ...process.env, PORT: String(port), FRAME_GRID_INSTANCE_ID: instanceId },
    stdio: ["ignore", stdout, stderr],
  });
  child.on("error", (error) => console.error(error.message));
  closeSync(stdout);
  closeSync(stderr);
  child.unref();
  let ready = null;
  for (let attempt = 0; attempt < 60; attempt++) {
    const candidate = await health(port);
    if (candidate?.instanceId === instanceId) { ready = candidate; break; }
    if (child.exitCode !== null) break;
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  if (!ready) {
    child.kill();
    throw new Error(`Server did not become ready. Inspect ${path.join(runtime, "server-error.log")}`);
  }
  await fs.writeFile(stateFile, JSON.stringify({ port, pid: ready.pid, instanceId }, null, 2));
  console.log(JSON.stringify({ running: true, url: `http://localhost:${port}`, pid: ready.pid }));
}
