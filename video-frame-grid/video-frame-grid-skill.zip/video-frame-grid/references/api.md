# 本机处理接口

对启动器返回的 URL 使用以下接口。接口无需外部服务，所有文件留在本机。

## 创建任务

`POST /api/jobs`，multipart/form-data：

| 字段 | 值 |
| --- | --- |
| video | 视频文件 |
| rows / columns | 各 1–10 的整数 |
| outputSize | 512、1024、2048、4096 |
| spacingPercent | 0–4，步进 0.25；默认界面为 0.75 |
| format | jpg 或 png |

返回 202 与任务对象，记录 `id`。每隔约 750 毫秒请求 `GET /api/jobs/:id`，直到 `status` 为 `done` 或 `error`。出现 `error` 时向用户报告任务的 `error` 字段，不下载旧结果。409 表示服务忙，等待现有任务完成后再提交；不要循环重复上传大文件。

## 下载与编辑

- `GET /api/jobs/:id/image?version=<revision>`：图片预览。
- `GET /api/jobs/:id/image?version=<revision>&download=1`：下载图片。需要交付独立文件时，把响应保存到用户目标目录并提供本地文件链接。
- `PATCH /api/jobs/:id/frames`，JSON `{"removedFrames":[1,6]}`：删除指定源视频帧。只能删除任务 `sampledFrames` 中的帧，使用从 1 开始的源帧序号；至少保留一帧。发送空数组恢复全部。列表表示累计删除集合。
- `PATCH /api/jobs/:id/spacing`，JSON `{"spacingPercent":1.5}`：更新当前任务的间距，保留原来的删除列表。
- 编辑返回 202 后重新轮询；`revision` 变化时更新预览 URL，避免缓存。
- `DELETE /api/jobs/:id`：取消并清理该临时任务。任务结果仍要交付时不要提前清理。

`layout` 返回实际画面的 `cellWidth`、`cellHeight`、`gap` 和整组布局的 `offsetX`、`offsetY`，均为输出图片像素。网页删帧选区使用相同坐标。
